<?php

namespace Mpdf\Tag;

class ColumnBreak extends NewColumn
{

}
